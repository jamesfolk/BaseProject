//
//  TotalTime.h
//  MazeADay
//
//  Created by James Folk on 12/21/13.
//  Copyright (c) 2013 JFArmy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TotalTime : NSManagedObject

@property (nonatomic, retain) NSNumber * totalTime;

@end
