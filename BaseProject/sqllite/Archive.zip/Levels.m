//
//  Levels.m
//  MazeADay
//
//  Created by James Folk on 12/21/13.
//  Copyright (c) 2013 JFArmy. All rights reserved.
//

#import "Levels.h"
#import "TotalTime.h"


@implementation Levels

@dynamic level;
@dynamic totalTime;

@end
