//
//  Day.m
//  MazeADay
//
//  Created by James Folk on 12/21/13.
//  Copyright (c) 2013 JFArmy. All rights reserved.
//

#import "Day.h"
#import "Levels.h"


@implementation Day

@dynamic datePlayed;
@dynamic levels;

@end
