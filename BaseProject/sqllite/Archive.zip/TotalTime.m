//
//  TotalTime.m
//  MazeADay
//
//  Created by James Folk on 12/21/13.
//  Copyright (c) 2013 JFArmy. All rights reserved.
//

#import "TotalTime.h"


@implementation TotalTime

@dynamic totalTime;

@end
